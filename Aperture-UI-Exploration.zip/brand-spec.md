# Aperture visual system

```css
:root {
  --bg: oklch(96.70% 0.0029 264.54);
  --surface: oklch(98.84% 0.0013 286.38);
  --fg: oklch(20.91% 0.0104 268.19);
  --muted: oklch(65.23% 0.0192 264.43);
  --border: oklch(89.39% 0.0088 264.52);
  --accent: oklch(39.44% 0.1381 264.43);
}
```

- Display: `Iowan Old Style`, `Charter`, `Georgia`, `Times New Roman`, serif
- Body: `-apple-system`, `BlinkMacSystemFont`, `Segoe UI`, system-ui, sans-serif
- Mono: `ui-monospace`, `JetBrains Mono`, `SFMono-Regular`, `Menlo`, monospace

Observed rules:

1. Separate interpretation from source material typographically: reading in serif/sans, records in mono.
2. Use a cool archival ground, pale reading surfaces, near-black ink, and deep ink-blue only for high-signal states.
3. Let hairlines and whitespace organize the interface; avoid ornamental cards and elevation.
4. Keep claim and verbatim quote visually paired, with the linked passage emphasized in the record.
5. Fold secondary research operations with native disclosure patterns so the primary reading flow stays uninterrupted.

The system is a cool, archival reading room in which analysis and source evidence remain unmistakably distinct.
